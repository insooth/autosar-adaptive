Document Title:                 Collection of blueprints for AUTOSAR Adaptive Platform M1 models
Document Owner:                 AUTOSAR
Document Responsibility:        AUTOSAR
Document Identification Number: 931
Document Status:                Final
Part of AUTOSAR Standard:       Adaptive Platform
Part of Standard Release:       19-03
Date:                           2019-03-29
